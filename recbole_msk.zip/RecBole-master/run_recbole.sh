################################################################################################################
# general
################################################################################################################
# BPR
python run_recbole.py --model=BPR --wandb_name='kms_BPR_CS' --dataset=ml-competition --config_files='./recbole/properties/overall_CS_msk.yaml ./recbole/properties/dataset/sample_msk.yaml'
# EASE
python run_recbole.py --model=EASE --wandb_name='kms_EASE_CS' --dataset=ml-competition --config_files='./recbole/properties/overall_CS_msk.yaml ./recbole/properties/dataset/sample_msk.yaml'
# NeuMF
python run_recbole.py --model=NeuMF --wandb_name='kms_NeuMF_CS' --dataset=ml-competition --config_files='./recbole/properties/overall_CS_msk.yaml ./recbole/properties/dataset/sample_msk.yaml'
python run_recbole.py --model=NeuMF --wandb_name='kms_NeuMF_LS' --dataset=ml-competition --config_files='./recbole/properties/overall_LS_msk.yaml ./recbole/properties/dataset/sample_msk.yaml'
# ngcf
python run_recbole.py --model=NGCF --wandb_name='kms_NGCF_CS' --dataset=ml-competition --config_files='./recbole/properties/overall_CS_msk.yaml ./recbole/properties/dataset/sample_msk.yaml'
python run_recbole.py --model=NGCF --wandb_name='kms_NGCF_LS' --dataset=ml-competition --config_files='./recbole/properties/overall_LS_msk.yaml ./recbole/properties/dataset/sample_msk.yaml'


################################################################################################################
# context-aware
################################################################################################################
# DCN
python run_recbole.py --model=DCN --wandb_name='kms_DCN_CS' --dataset=ml-competition --config_files='./recbole/properties/overall_CS_msk.yaml ./recbole/properties/dataset/sample_feat_msk.yaml'
# DeepFM
python run_recbole.py --model=DeepFM --wandb_name='kms_DeepFM_CS' --dataset=ml-competition --config_files='./recbole/properties/overall_CS_msk.yaml ./recbole/properties/dataset/sample_feat_msk.yaml'
# FM
python run_recbole.py --model=FM --wandb_name='kms_FM_CS' --dataset=ml-competition --config_files='./recbole/properties/overall_CS_msk.yaml ./recbole/properties/dataset/sample_feat_msk.yaml'
# FFM
python run_recbole.py --model=FFM --wandb_name='kms_FFM_CS' --dataset=ml-competition --config_files='./recbole/properties/overall_CS_msk.yaml ./recbole/properties/dataset/sample_feat_msk.yaml'
# WideDeep
python run_recbole.py --model=WideDeep --wandb_name='kms_WideDeep_CS' --dataset=ml-competition --config_files='./recbole/properties/overall_CS_msk.yaml ./recbole/properties/dataset/sample_feat_msk.yaml'