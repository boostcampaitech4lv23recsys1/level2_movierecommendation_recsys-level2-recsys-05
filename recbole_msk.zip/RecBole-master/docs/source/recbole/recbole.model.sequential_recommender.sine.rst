.. automodule:: recbole.model.sequential_recommender.sine
   :members:
   :undoc-members:
   :show-inheritance:
