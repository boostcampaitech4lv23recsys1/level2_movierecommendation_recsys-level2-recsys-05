.. automodule:: recbole.model.sequential_recommender.dien
   :members:
   :undoc-members:
   :show-inheritance:
