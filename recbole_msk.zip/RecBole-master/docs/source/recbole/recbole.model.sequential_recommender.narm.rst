.. automodule:: recbole.model.sequential_recommender.narm
   :members:
   :undoc-members:
   :show-inheritance:
