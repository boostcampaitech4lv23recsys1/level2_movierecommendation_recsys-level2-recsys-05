.. automodule:: recbole.model.context_aware_recommender.afm
   :members:
   :undoc-members:
   :show-inheritance:
