.. automodule:: recbole.model.general_recommender.ngcf
   :members:
   :undoc-members:
   :show-inheritance:
