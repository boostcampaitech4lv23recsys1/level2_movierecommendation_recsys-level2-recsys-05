.. automodule:: recbole.model.general_recommender.itemknn
   :members:
   :undoc-members:
   :show-inheritance:
