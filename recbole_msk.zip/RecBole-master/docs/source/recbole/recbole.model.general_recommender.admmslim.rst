.. automodule:: recbole.model.general_recommender.admmslim
   :members:
   :undoc-members:
   :show-inheritance:
