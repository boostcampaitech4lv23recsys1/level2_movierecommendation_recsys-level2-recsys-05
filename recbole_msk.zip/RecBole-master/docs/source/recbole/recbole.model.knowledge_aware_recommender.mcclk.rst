.. automodule:: recbole.model.knowledge_aware_recommender.mcclk
   :members:
   :undoc-members:
   :show-inheritance:
