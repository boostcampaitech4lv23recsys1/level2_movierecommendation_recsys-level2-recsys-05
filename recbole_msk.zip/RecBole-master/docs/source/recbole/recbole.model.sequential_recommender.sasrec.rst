.. automodule:: recbole.model.sequential_recommender.sasrec
   :members:
   :undoc-members:
   :show-inheritance:
