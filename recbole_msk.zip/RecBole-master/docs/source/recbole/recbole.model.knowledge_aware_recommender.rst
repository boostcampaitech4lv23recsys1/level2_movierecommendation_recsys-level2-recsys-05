recbole.model.knowledge\_aware\_recommender
===================================================

.. toctree::
   :maxdepth: 4

   recbole.model.knowledge_aware_recommender.cfkg
   recbole.model.knowledge_aware_recommender.cke
   recbole.model.knowledge_aware_recommender.kgat
   recbole.model.knowledge_aware_recommender.kgcn
   recbole.model.knowledge_aware_recommender.kgnnls
   recbole.model.knowledge_aware_recommender.ktup
   recbole.model.knowledge_aware_recommender.mkr
   recbole.model.knowledge_aware_recommender.ripplenet
