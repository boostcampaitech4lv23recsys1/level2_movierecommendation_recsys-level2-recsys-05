.. automodule:: recbole.model.exlib_recommender.xgboost
   :members:
   :undoc-members:
   :show-inheritance:
