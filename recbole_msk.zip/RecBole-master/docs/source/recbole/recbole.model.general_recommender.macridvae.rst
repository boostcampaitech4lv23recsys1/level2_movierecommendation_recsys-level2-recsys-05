.. automodule:: recbole.model.general_recommender.macridvae
   :members:
   :undoc-members:
   :show-inheritance:
