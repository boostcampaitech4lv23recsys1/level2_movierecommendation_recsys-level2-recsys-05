.. automodule:: recbole.model.sequential_recommender.repeatnet
   :members:
   :undoc-members:
   :show-inheritance:
