.. automodule:: recbole.utils.enum_type
   :members:
   :undoc-members:
   :show-inheritance:
