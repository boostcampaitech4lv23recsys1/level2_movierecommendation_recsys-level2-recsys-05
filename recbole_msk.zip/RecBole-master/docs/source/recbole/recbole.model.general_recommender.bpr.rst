.. automodule:: recbole.model.general_recommender.bpr
   :members:
   :undoc-members:
   :show-inheritance:
