.. automodule:: recbole.model.knowledge_aware_recommender.cke
   :members:
   :undoc-members:
   :show-inheritance:
