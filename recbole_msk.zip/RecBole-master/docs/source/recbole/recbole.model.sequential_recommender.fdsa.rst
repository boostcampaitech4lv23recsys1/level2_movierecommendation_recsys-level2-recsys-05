.. automodule:: recbole.model.sequential_recommender.fdsa
   :members:
   :undoc-members:
   :show-inheritance:
