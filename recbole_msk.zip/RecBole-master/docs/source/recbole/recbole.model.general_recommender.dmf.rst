.. automodule:: recbole.model.general_recommender.dmf
   :members:
   :undoc-members:
   :show-inheritance:
