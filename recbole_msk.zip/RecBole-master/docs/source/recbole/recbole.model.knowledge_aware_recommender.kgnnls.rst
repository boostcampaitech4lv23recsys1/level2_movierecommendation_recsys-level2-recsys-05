.. automodule:: recbole.model.knowledge_aware_recommender.kgnnls
   :members:
   :undoc-members:
   :show-inheritance:
