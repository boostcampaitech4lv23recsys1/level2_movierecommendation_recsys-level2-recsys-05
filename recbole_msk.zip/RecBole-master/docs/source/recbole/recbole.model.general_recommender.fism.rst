.. automodule:: recbole.model.general_recommender.fism
   :members:
   :undoc-members:
   :show-inheritance:
