recbole.model.exlib\_recommender
=============================================

.. toctree::
   :maxdepth: 4

   recbole.model.exlib_recommender.xgboost
   recbole.model.exlib_recommender.lightgbm
