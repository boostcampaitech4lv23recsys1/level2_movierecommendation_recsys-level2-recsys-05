.. automodule:: recbole.model.sequential_recommender.hgn
   :members:
   :undoc-members:
   :show-inheritance:
