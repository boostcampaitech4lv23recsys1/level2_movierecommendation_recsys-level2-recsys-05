.. automodule:: recbole.model.sequential_recommender.nextitnet
   :members:
   :undoc-members:
   :show-inheritance:
