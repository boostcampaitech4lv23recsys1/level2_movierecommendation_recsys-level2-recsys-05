.. automodule:: recbole.model.sequential_recommender.npe
   :members:
   :undoc-members:
   :show-inheritance:
