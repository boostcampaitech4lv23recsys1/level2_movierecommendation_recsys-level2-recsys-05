.. automodule:: recbole.model.knowledge_aware_recommender.cfkg
   :members:
   :undoc-members:
   :show-inheritance:
