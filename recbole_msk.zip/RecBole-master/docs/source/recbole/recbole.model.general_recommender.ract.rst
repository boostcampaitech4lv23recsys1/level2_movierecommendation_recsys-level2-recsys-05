.. automodule:: recbole.model.general_recommender.ract
   :members:
   :undoc-members:
   :show-inheritance: